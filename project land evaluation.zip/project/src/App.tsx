import React, { useState } from 'react';
import { EvaluationForm } from './components/EvaluationForm';
import { EvaluationResult } from './components/EvaluationResult';
import { evaluateLand } from './utils/evaluationLogic';
import type { EvaluationCriteria, EvaluationResult as EvaluationResultType } from './types';
import { Factory } from 'lucide-react';

function App() {
  const [result, setResult] = useState<EvaluationResultType | null>(null);

  const handleEvaluation = (criteria: EvaluationCriteria) => {
    const evaluationResult = evaluateLand(criteria);
    setResult(evaluationResult);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <Factory className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">Factory Land Evaluation System</h1>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <EvaluationForm onSubmit={handleEvaluation} />
          </div>
          <div>
            {result && <EvaluationResult result={result} />}
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;
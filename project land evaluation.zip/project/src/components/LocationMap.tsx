import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Circle, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import type { Location } from '../types';

interface LocationMapProps {
  location: Location;
  requiredArea: number;
}

export function LocationMap({ location, requiredArea }: LocationMapProps) {
  // Calculate radius in meters (1 acre ≈ 4046.86 square meters)
  // Area = πr², so r = √(A/π)
  const areaInSqMeters = requiredArea * 4046.86;
  const radiusInMeters = Math.sqrt(areaInSqMeters / Math.PI);

  // Fix for Leaflet default icon path issue in production
  useEffect(() => {
    // @ts-ignore
    delete L.Icon.Default.prototype._getIconUrl;
    // @ts-ignore
    L.Icon.Default.mergeOptions({
      iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
      iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
      shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
    });
  }, []);

  return (
    <div className="h-[400px] w-full rounded-lg overflow-hidden shadow-lg">
      <MapContainer
        center={[location.coordinates.lat, location.coordinates.lng]}
        zoom={15}
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <Circle
          center={[location.coordinates.lat, location.coordinates.lng]}
          radius={radiusInMeters}
          pathOptions={{
            color: location.availableArea >= requiredArea ? 'green' : 'red',
            fillColor: location.availableArea >= requiredArea ? '#4ade80' : '#ef4444',
            fillOpacity: 0.3
          }}
        >
          <Popup>
            <div className="p-2">
              <h3 className="font-semibold">{location.name}</h3>
              <p className="text-sm">Required: {requiredArea} acres</p>
              <p className="text-sm">Available: {location.availableArea} acres</p>
              <p className="text-sm mt-1">
                Status: {location.availableArea >= requiredArea ? (
                  <span className="text-green-600">Sufficient Area</span>
                ) : (
                  <span className="text-red-600">Insufficient Area</span>
                )}
              </p>
            </div>
          </Popup>
        </Circle>
      </MapContainer>
    </div>
  );
}
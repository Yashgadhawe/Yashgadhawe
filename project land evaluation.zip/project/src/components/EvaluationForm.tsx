import React, { useState } from 'react';
import { Slider } from './Slider';
import { Toggle } from './Toggle';
import { LocationSearch } from './LocationSearch';
import type { EvaluationCriteria, Location, LocationAnalysis } from '../types';
import { AlertTriangle, CheckCircle, Factory, MapPin } from 'lucide-react';

export function EvaluationForm({ 
  onSubmit 
}: { 
  onSubmit: (data: EvaluationCriteria) => void 
}) {
  const [formData, setFormData] = useState<EvaluationCriteria>({
    location: null,
    analysis: null,
    soilStability: 5,
    floodRisk: 5,
    seismicActivity: 5,
    proximityToResources: 5,
    transportAccess: 5,
    powerAvailability: 5,
    waterAvailability: 5,
    environmentalImpact: 5,
    zoningCompliance: true,
    costPerAcre: 50000,
    requiredArea: 10
  });

  const handleLocationSelect = (location: Location, analysis: LocationAnalysis) => {
    setFormData({
      ...formData,
      location,
      analysis,
      soilStability: analysis.soilData.stability,
      floodRisk: analysis.climate.floodRisk,
      seismicActivity: analysis.climate.seismicRisk,
      transportAccess: analysis.infrastructure.transportScore,
      powerAvailability: analysis.infrastructure.powerScore,
      waterAvailability: analysis.infrastructure.waterScore,
      environmentalImpact: analysis.environmental.impactScore,
      zoningCompliance: analysis.zoning.allowsIndustrial,
      costPerAcre: analysis.costEstimate.averagePricePerAcre
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.location) {
      alert('Please select a location first');
      return;
    }
    onSubmit(formData);
  };

  // Convert USD to INR (using a fixed exchange rate for demonstration)
  const usdToInr = (usd: number) => {
    const exchangeRate = 83; // Current approximate exchange rate
    return Math.round(usd * exchangeRate);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 rounded-lg shadow-lg">
      <div className="flex items-center gap-2 mb-6">
        <Factory className="w-6 h-6 text-blue-600" />
        <h2 className="text-2xl font-bold text-gray-800">Land Evaluation Parameters</h2>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-700 flex items-center gap-2">
          <MapPin className="w-5 h-5 text-blue-500" />
          Location Search
        </h3>
        <LocationSearch onLocationSelect={handleLocationSelect} />
        
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium text-gray-700">Required Land Area (Acres)</label>
          <input
            type="number"
            value={formData.requiredArea}
            onChange={(e) => setFormData({ ...formData, requiredArea: Math.max(0, Number(e.target.value)) })}
            min="0"
            step="0.1"
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        
        {formData.location && (
          <div className="p-4 bg-blue-50 rounded-md">
            <h4 className="font-medium text-blue-900">Selected Location:</h4>
            <p className="text-sm text-blue-800">{formData.location.address}</p>
            <p className="text-sm text-blue-800 mt-1">
              Available Area: {formData.location.availableArea.toFixed(2)} acres
              {formData.location.availableArea < formData.requiredArea && (
                <span className="text-red-600 ml-2">
                  (Insufficient area - need {formData.requiredArea} acres)
                </span>
              )}
            </p>
            {formData.analysis && (
              <div className="mt-2 text-sm text-blue-700">
                <p>Soil Type: {formData.analysis.soilData.type}</p>
                <p>Climate: {formData.analysis.climate.description}</p>
                <p>Nearby Facilities: {formData.analysis.infrastructure.nearbyFacilities.join(', ')}</p>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-700 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-blue-500" />
            Geographical Factors
          </h3>
          
          <Slider
            label="Soil Stability"
            value={formData.soilStability}
            onChange={(value) => setFormData({ ...formData, soilStability: value })}
          />
          
          <Slider
            label="Flood Risk"
            value={formData.floodRisk}
            onChange={(value) => setFormData({ ...formData, floodRisk: value })}
          />
          
          <Slider
            label="Seismic Activity"
            value={formData.seismicActivity}
            onChange={(value) => setFormData({ ...formData, seismicActivity: value })}
          />
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-700 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-yellow-500" />
            Infrastructure Assessment
          </h3>
          
          <Slider
            label="Transport Access"
            value={formData.transportAccess}
            onChange={(value) => setFormData({ ...formData, transportAccess: value })}
          />
          
          <Slider
            label="Power Availability"
            value={formData.powerAvailability}
            onChange={(value) => setFormData({ ...formData, powerAvailability: value })}
          />
          
          <Slider
            label="Water Availability"
            value={formData.waterAvailability}
            onChange={(value) => setFormData({ ...formData, waterAvailability: value })}
          />
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-700 flex items-center gap-2">
          <CheckCircle className="w-5 h-5 text-green-500" />
          Environmental & Compliance
        </h3>
        
        <Slider
          label="Environmental Impact"
          value={formData.environmentalImpact}
          onChange={(value) => setFormData({ ...formData, environmentalImpact: value })}
        />
        
        <Toggle
          label="Zoning Compliance"
          checked={formData.zoningCompliance}
          onChange={(checked) => setFormData({ ...formData, zoningCompliance: checked })}
        />
        
        <div className="flex flex-col gap-2">
          <label className="text-sm font-medium text-gray-700">Cost per Acre</label>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-xs text-gray-500">USD</label>
              <input
                type="number"
                value={formData.costPerAcre}
                onChange={(e) => setFormData({ ...formData, costPerAcre: Number(e.target.value) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="text-xs text-gray-500">INR (₹)</label>
              <input
                type="number"
                value={usdToInr(formData.costPerAcre)}
                onChange={(e) => setFormData({ ...formData, costPerAcre: Math.round(Number(e.target.value) / 83) })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>
      </div>

      <button
        type="submit"
        className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
      >
        Evaluate Land
      </button>
    </form>
  );
}
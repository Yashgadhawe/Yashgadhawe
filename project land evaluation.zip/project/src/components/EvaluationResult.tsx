import React from 'react';
import type { EvaluationResult } from '../types';
import { CheckCircle2, AlertTriangle, XCircle, MapPin } from 'lucide-react';
import { LocationMap } from './LocationMap';

interface ResultProps {
  result: EvaluationResult;
}

export function EvaluationResult({ result }: ResultProps) {
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getComplianceIcon = () => {
    switch (result.complianceStatus) {
      case 'Compliant':
        return <CheckCircle2 className="w-6 h-6 text-green-600" />;
      case 'Needs Review':
        return <AlertTriangle className="w-6 h-6 text-yellow-600" />;
      case 'Non-Compliant':
        return <XCircle className="w-6 h-6 text-red-600" />;
    }
  };

  // Convert USD to INR
  const usdToInr = (usd: number) => {
    const exchangeRate = 83; // Current approximate exchange rate
    return Math.round(usd * exchangeRate);
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-800">Evaluation Results</h2>
        {getComplianceIcon()}
      </div>

      {result.location && (
        <>
          <div className="bg-blue-50 p-4 rounded-md">
            <div className="flex items-start gap-2">
              <MapPin className="w-5 h-5 text-blue-500 mt-1" />
              <div>
                <h3 className="font-medium text-blue-900">{result.location.name}</h3>
                <p className="text-sm text-blue-800">{result.location.address}</p>
                <div className="text-xs text-blue-600 mt-1">
                  Coordinates: {result.location.coordinates.lat.toFixed(4)}, {result.location.coordinates.lng.toFixed(4)}
                </div>
                <div className="mt-2 text-sm text-blue-800">
                  <p>Required Area: {result.requiredArea} acres</p>
                  <p>Available Area: {result.location.availableArea} acres</p>
                  {!result.areaAvailable && (
                    <p className="text-red-600">
                      Insufficient area available at this location
                    </p>
                  )}
                  <p>Cost per Acre: ${result.analysis?.costEstimate.averagePricePerAcre.toLocaleString()} USD</p>
                  <p>Cost per Acre: ₹{usdToInr(result.analysis?.costEstimate.averagePricePerAcre || 0).toLocaleString()} INR</p>
                  <p className="font-semibold mt-1">
                    Total Cost: ${(result.requiredArea * (result.analysis?.costEstimate.averagePricePerAcre || 0)).toLocaleString()} USD
                  </p>
                  <p className="font-semibold">
                    Total Cost: ₹{usdToInr(result.requiredArea * (result.analysis?.costEstimate.averagePricePerAcre || 0)).toLocaleString()} INR
                  </p>
                </div>
              </div>
            </div>
          </div>

          <LocationMap location={result.location} requiredArea={result.requiredArea} />
        </>
      )}

      <div className="text-center">
        <div className={`text-4xl font-bold mb-2 ${getScoreColor(result.score)}`}>
          {result.score}%
        </div>
        <div className="text-gray-600">Overall Suitability Score</div>
      </div>

      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Risk Factors</h3>
          <ul className="list-disc list-inside space-y-1">
            {result.riskFactors.map((risk, index) => (
              <li key={index} className="text-red-600">{risk}</li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Recommendations</h3>
          <ul className="list-disc list-inside space-y-1">
            {result.recommendations.map((rec, index) => (
              <li key={index} className="text-green-600">{rec}</li>
            ))}
          </ul>
        </div>

        <div className="pt-4 border-t">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-gray-700">Compliance Status:</span>
            <span className={`${
              result.complianceStatus === 'Compliant' ? 'text-green-600' :
              result.complianceStatus === 'Needs Review' ? 'text-yellow-600' :
              'text-red-600'
            }`}>
              {result.complianceStatus}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
export interface Location {
  id: string;
  name: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  address: string;
  area: number;
  availableArea: number;
}

export interface LocationAnalysis {
  soilData: {
    stability: number;
    type: string;
    description: string;
  };
  climate: {
    floodRisk: number;
    seismicRisk: number;
    averageRainfall: number;
    description: string;
  };
  infrastructure: {
    transportScore: number;
    powerScore: number;
    waterScore: number;
    nearbyFacilities: string[];
  };
  environmental: {
    impactScore: number;
    protectedAreas: boolean;
    concerns: string[];
  };
  zoning: {
    allowsIndustrial: boolean;
    restrictions: string[];
  };
  costEstimate: {
    averagePricePerAcre: number;
    factors: string[];
  };
}

export interface EvaluationCriteria {
  location: Location | null;
  analysis: LocationAnalysis | null;
  soilStability: number;
  floodRisk: number;
  seismicActivity: number;
  proximityToResources: number;
  transportAccess: number;
  powerAvailability: number;
  waterAvailability: number;
  environmentalImpact: number;
  zoningCompliance: boolean;
  costPerAcre: number;
  requiredArea: number;
}

export interface EvaluationResult {
  score: number;
  recommendations: string[];
  riskFactors: string[];
  complianceStatus: 'Compliant' | 'Non-Compliant' | 'Needs Review';
  location: Location | null;
  analysis: LocationAnalysis | null;
  areaAvailable: boolean;
  requiredArea: number;
}
import type { EvaluationCriteria, EvaluationResult } from '../types';

export function evaluateLand(criteria: EvaluationCriteria): EvaluationResult {
  // Calculate base score
  const weights = {
    soilStability: 0.15,
    floodRisk: 0.15,
    seismicActivity: 0.1,
    proximityToResources: 0.1,
    transportAccess: 0.1,
    powerAvailability: 0.1,
    waterAvailability: 0.1,
    environmentalImpact: 0.2
  };

  let score = 0;
  for (const [key, weight] of Object.entries(weights)) {
    score += (criteria[key as keyof typeof weights] * weight * 10);
  }

  // Adjust score based on zoning compliance
  if (!criteria.zoningCompliance) {
    score *= 0.5;
  }

  // Cost factor adjustment
  const costFactor = Math.max(0, 1 - (criteria.costPerAcre - 50000) / 100000);
  score *= costFactor;

  // Check if required area is available
  const areaAvailable = criteria.location?.availableArea >= criteria.requiredArea;
  if (!areaAvailable) {
    score *= 0.5; // Reduce score if required area is not available
  }

  // Generate risk factors
  const riskFactors: string[] = [];
  if (!areaAvailable) riskFactors.push(`Insufficient land area - need ${criteria.requiredArea} acres but only ${criteria.location?.availableArea} acres available`);
  if (criteria.soilStability < 6) riskFactors.push('Poor soil stability may require additional foundation work');
  if (criteria.floodRisk > 7) riskFactors.push('High flood risk area - flood protection measures needed');
  if (criteria.seismicActivity > 7) riskFactors.push('Significant seismic activity - specialized construction required');
  if (criteria.environmentalImpact > 7) riskFactors.push('High environmental impact - mitigation measures needed');

  // Generate recommendations
  const recommendations: string[] = [];
  if (!areaAvailable) recommendations.push('Consider searching for alternative locations with sufficient area');
  if (criteria.soilStability < 6) recommendations.push('Conduct detailed soil analysis and consider soil reinforcement');
  if (criteria.transportAccess < 5) recommendations.push('Investigate transportation infrastructure improvements');
  if (criteria.powerAvailability < 5) recommendations.push('Consider on-site power generation capabilities');
  if (criteria.waterAvailability < 5) recommendations.push('Evaluate water source alternatives and storage solutions');

  // Determine compliance status
  let complianceStatus: 'Compliant' | 'Non-Compliant' | 'Needs Review';
  if (!criteria.zoningCompliance) {
    complianceStatus = 'Non-Compliant';
  } else if (riskFactors.length > 2) {
    complianceStatus = 'Needs Review';
  } else {
    complianceStatus = 'Compliant';
  }

  return {
    score: Math.round(score),
    riskFactors,
    recommendations,
    complianceStatus,
    location: criteria.location,
    analysis: criteria.analysis,
    areaAvailable,
    requiredArea: criteria.requiredArea
  };
}
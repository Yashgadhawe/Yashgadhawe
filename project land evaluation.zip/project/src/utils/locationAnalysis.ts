import type { Location, LocationAnalysis } from '../types';

// Mock data generator functions
function getMockSoilData(lat: number, lng: number) {
  const stability = 5 + (Math.cos(lat) + Math.sin(lng)) * 2.5; // Generate value between 0-10
  return {
    stability: Math.min(Math.max(stability, 0), 10),
    type: ['Clay', 'Sandy Loam', 'Silt', 'Rocky', 'Loamy'][Math.floor(Math.random() * 5)],
    description: 'Soil composition suitable for industrial construction'
  };
}

function getMockClimateData(lat: number) {
  // More extreme conditions near equator (lat = 0) and poles (lat = ±90)
  const latitudeFactor = Math.abs(lat) / 90;
  return {
    floodRisk: Math.min(Math.max(5 - latitudeFactor * 3, 0), 10),
    seismicRisk: Math.min(Math.max(3 + Math.random() * 4, 0), 10),
    averageRainfall: 500 + Math.random() * 1500,
    description: `Moderate climate with seasonal variations`
  };
}

function getMockInfrastructureData(lat: number, lng: number) {
  // Better infrastructure in mid-latitudes (developed regions)
  const developmentFactor = 1 - Math.abs(lat - 45) / 45;
  return {
    transportScore: Math.min(Math.max(developmentFactor * 8 + Math.random() * 2, 0), 10),
    powerScore: Math.min(Math.max(developmentFactor * 7 + Math.random() * 3, 0), 10),
    waterScore: Math.min(Math.max(developmentFactor * 6 + Math.random() * 4, 0), 10),
    nearbyFacilities: [
      'Industrial Park',
      'Power Station',
      'Water Treatment Plant',
      'Highway Access',
      'Railway Station'
    ].slice(0, Math.floor(developmentFactor * 5))
  };
}

function getMockAvailableArea(lat: number, lng: number) {
  // Generate a random available area between 5 and 100 acres
  const baseFactor = Math.abs(Math.sin(lat) * Math.cos(lng));
  return Math.round((5 + baseFactor * 95) * 100) / 100;
}

export async function analyzeLocation(location: Location): Promise<LocationAnalysis> {
  const { lat, lng } = location.coordinates;
  
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));

  // Set available area
  location.availableArea = getMockAvailableArea(lat, lng);

  const soilData = getMockSoilData(lat, lng);
  const climate = getMockClimateData(lat);
  const infrastructure = getMockInfrastructureData(lat, lng);

  // Environmental impact based on infrastructure density
  const environmental = {
    impactScore: Math.min(10 - infrastructure.transportScore * 0.5, 10),
    protectedAreas: Math.random() > 0.8,
    concerns: []
  };

  // Zoning more likely to be favorable in areas with good infrastructure
  const zoning = {
    allowsIndustrial: infrastructure.transportScore > 5,
    restrictions: []
  };

  // Cost influenced by infrastructure quality
  const costEstimate = {
    averagePricePerAcre: 50000 + (infrastructure.transportScore * 10000),
    factors: ['Location accessibility', 'Infrastructure availability']
  };

  return {
    soilData,
    climate,
    infrastructure,
    environmental,
    zoning,
    costEstimate
  };
}